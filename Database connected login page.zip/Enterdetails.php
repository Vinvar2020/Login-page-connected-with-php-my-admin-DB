<?php
$n = $_POST['stname'];
$c = $_POST['stclass'];
$con = mysqli_connect("localhost", "root", "", "company");

// Check if the connection was successful
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

$sql = "INSERT INTO studentsdetails (Student_name, Student_class) VALUES ('$n', '$c')";

if (mysqli_query($con, $sql)) {
    echo "Student details added successfully";
} else {
    echo "Student details not added successfully: " . mysqli_error($con);
}

// Close the connection
mysqli_close($con);
?>
